# Web-XSS

## xss_test1
了解web xss攻击入门练习例子。

## xss_test

实战：比较全面的操作防御web xss 防御。
不足： encode.js 和 DOMParser.js 文件还存在问题，带解决。
